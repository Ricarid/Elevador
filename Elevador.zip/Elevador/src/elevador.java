import java.util.Scanner;

public class elevador {
    public static void main(String[] args) {

        int andar = 0;
        boolean portaAberta = false;
        boolean rodando = true;

        System.out.println("""
                O elevador ira:
                subir = ira subir
                descer = ira descer
                AbrirPorta = abrira a porta
                FecharPorta = fechara a porta
                Indicar = Indicara se a porta está aberta ou fechada
                andarAtual = Mostrara o andar atual
                sair = Sai
                """);


        Scanner leitor = new Scanner(System.in);

        while (rodando) {


            String escolha = leitor.nextLine();


            if (escolha.equalsIgnoreCase("subir")) {
                andar = andar + 1;
                System.out.println("O elevador esta subindo");
            }
            else if (escolha.equalsIgnoreCase("descer")) {
                andar = andar - 1;
                System.out.println("O elevador esta descendo");
            }
            else if (escolha.equalsIgnoreCase("AbrirPorta")) {
                portaAberta = true;
                System.out.println("Abrindo porta");
            }
            else if (escolha.equalsIgnoreCase("FecharPorta")) {
                portaAberta = false;
                System.out.println("Fechando porta");
            }
            else if (escolha.equalsIgnoreCase("Indicar")) {

                if (portaAberta == true) {
                    System.out.println("A porta esta aberta");
                } else {
                    System.out.println("A porta esta fechada");                }
            }
            else if (escolha.equalsIgnoreCase("andarAtual")) {

                System.out.println("Voce esta no andar " + andar);
            }
            else if (escolha.equalsIgnoreCase("sair")) {

                System.out.println("Saindo");
                rodando = false;
            }
            else {
                System.out.println("Comando inválido. Tente novamente.");
            }
        }


        leitor.close();
    }
}